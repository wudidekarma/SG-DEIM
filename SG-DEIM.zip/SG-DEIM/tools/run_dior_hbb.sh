#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$repo_root"
python_bin="${PYTHON_BIN:-/home/user1/anaconda3/envs/deimv2/bin/python}"

for split in train val test; do
  if [[ ! -s "data/dior/annotations/${split}.json" ]]; then
    echo "Missing DIOR annotation: data/dior/annotations/${split}.json" >&2
    echo "Run: python3 tools/dataset/prepare_dior_hbb.py" >&2
    exit 1
  fi
done
if [[ ! -s ckpts/vitt_distill.pt ]]; then
  echo "Missing S backbone checkpoint: ckpts/vitt_distill.pt" >&2
  exit 1
fi

"$python_bin" - <<'PY'
import torch
if torch.cuda.device_count() < 2:
    raise SystemExit("Two visible CUDA GPUs are required for two-GPU DDP training")
print("CUDA GPUs available:", torch.cuda.device_count())
PY

mkdir -p outputs/SG-DEIM_dinov3_s_dior_hbb_800_bs8 outputs/DEIMv2_dinov3_s_dior_hbb_800_bs8

echo "Training SG-DEIM-S on GPUs 0 and 1"
CUDA_VISIBLE_DEVICES=0,1 "$python_bin" -m torch.distributed.run \
  --standalone --nproc_per_node=2 train.py --use-amp --seed 0 \
  -c configs/sgdeim/sgdeim_dinov3_s_dior_hbb.yml \
  2>&1 | tee outputs/SG-DEIM_dinov3_s_dior_hbb_800_bs8/launcher.log

echo "SG-DEIM-S complete. Training DEIMv2-S on GPUs 0 and 1"
CUDA_VISIBLE_DEVICES=0,1 "$python_bin" -m torch.distributed.run \
  --standalone --nproc_per_node=2 train.py --use-amp --seed 0 \
  -c configs/deimv2/deimv2_dinov3_s_dior_hbb.yml \
  2>&1 | tee outputs/DEIMv2_dinov3_s_dior_hbb_800_bs8/launcher.log

echo "Both two-GPU experiments completed."
