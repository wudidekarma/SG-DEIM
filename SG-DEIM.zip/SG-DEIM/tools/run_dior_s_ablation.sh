#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$repo_root"

usage() {
  cat <<'EOF'
Usage: bash tools/run_dior_s_ablation.sh [--dry-run] [all | CODE ...]

CODE has three bits in the order CGSR, CSAI, QCAG:
  000 baseline       100 CGSR          010 CSAI          001 QCAG
  110 CGSR+CSAI      101 CGSR+QCAG     011 CSAI+QCAG     111 full

With no codes, run all eight experiments sequentially using two GPUs per run.
--dry-run prints commands without training or creating output directories.

Environment:
  PYTHON_BIN           default: /home/user1/anaconda3/envs/deimv2/bin/python
  CUDA_VISIBLE_DEVICES default: 0,1 (exactly two visible GPUs are required)
  SEED                 default: 0
  OUTPUT_ROOT          default: ./outputs/SG-DEIM_S_DIOR_ablation
EOF
}

dry_run=false
variants=()
for arg in "$@"; do
  case "$arg" in
    --dry-run) dry_run=true ;;
    -h|--help) usage; exit 0 ;;
    all|000|100|010|001|110|101|011|111) variants+=("$arg") ;;
    *) echo "Unknown argument: $arg" >&2; usage >&2; exit 1 ;;
  esac
done

if [[ ${#variants[@]} -eq 0 || "${variants[*]}" == all ]]; then
  variants=(000 100 010 001 110 101 011 111)
elif [[ " ${variants[*]} " == *" all "* ]]; then
  echo "Use 'all' alone, or specify individual experiment codes." >&2
  exit 1
fi

python_bin="${PYTHON_BIN:-/home/user1/anaconda3/envs/deimv2/bin/python}"
visible_devices="${CUDA_VISIBLE_DEVICES:-0,1}"
seed="${SEED:-0}"
output_root="${OUTPUT_ROOT:-./outputs/SG-DEIM_S_DIOR_ablation}"
if [[ ! "$seed" =~ ^[0-9]+$ ]]; then
  echo "SEED must be a nonnegative integer." >&2
  exit 1
fi

if [[ "$dry_run" == false ]]; then
  for split in train val; do
    if [[ ! -s "data/dior/annotations/${split}.json" ]]; then
      echo "Missing data/dior/annotations/${split}.json; run tools/dataset/prepare_dior_hbb.py." >&2
      exit 1
    fi
  done
  if [[ ! -s ckpts/vitt_distill.pt ]]; then
    echo "Missing S backbone checkpoint: ckpts/vitt_distill.pt" >&2
    exit 1
  fi
  CUDA_VISIBLE_DEVICES="$visible_devices" "$python_bin" - <<'PY'
import torch
if not torch.cuda.is_available() or torch.cuda.device_count() != 2:
    raise SystemExit("Exactly two visible CUDA GPUs are required for this batch-8 DDP recipe.")
print("CUDA GPUs:", [torch.cuda.get_device_name(i) for i in range(2)])
PY
fi

for variant in "${variants[@]}"; do
  cgsr=False
  csai=False
  qcag=False
  [[ "${variant:0:1}" == 1 ]] && cgsr=True
  [[ "${variant:1:1}" == 1 ]] && csai=True
  [[ "${variant:2:1}" == 1 ]] && qcag=True
  output_dir="${output_root}/${variant}/seed${seed}"
  command=(
    env "CUDA_VISIBLE_DEVICES=$visible_devices" "$python_bin"
    -m torch.distributed.run --standalone --nproc_per_node=2 train.py
    --use-amp --seed "$seed"
    -c configs/sgdeim/sgdeim_dinov3_s_dior_hbb.yml
    --output-dir "$output_dir"
    -u "SGDEIMEncoder.use_cgsr=$cgsr"
       "SGDEIMEncoder.use_csai=$csai"
       "DEIMTransformer.use_qcag=$qcag"
  )
  printf '\nExperiment %s (CGSR=%s, CSAI=%s, QCAG=%s)\n' "$variant" "$cgsr" "$csai" "$qcag"
  printf '%q ' "${command[@]}"
  printf '\n'
  if [[ "$dry_run" == true ]]; then
    continue
  fi
  if [[ -s "${output_dir}/train_stdout.log" ]]; then
    echo "Existing run at $output_dir; choose a new OUTPUT_ROOT to keep its results." >&2
    exit 1
  fi
  mkdir -p "$output_dir"
  printf '%q ' "${command[@]}" > "${output_dir}/command.txt"
  printf '\n' >> "${output_dir}/command.txt"
  "${command[@]}" 2>&1 | tee "${output_dir}/launcher.log"
done
