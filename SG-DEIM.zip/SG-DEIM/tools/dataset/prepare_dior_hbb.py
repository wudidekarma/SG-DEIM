"""Convert the original DIOR horizontal XML boxes to COCO JSON.

The source images remain in the OpenDataLab directory; only annotations are
written to this repository. Run from any working directory.
"""

import argparse
import json
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path


CLASSES = (
    "airplane", "airport", "baseballfield", "basketballcourt", "bridge",
    "chimney", "dam", "Expressway-Service-area", "Expressway-toll-station",
    "golffield", "groundtrackfield", "harbor", "overpass", "ship",
    "stadium", "storagetank", "tenniscourt", "trainstation", "vehicle",
    "windmill",
)


def convert_split(root: Path, split: str, output: Path) -> dict:
    ids = (root / "ImageSets" / "Main" / f"{split}.txt").read_text().split()
    if len(ids) != len(set(ids)):
        raise ValueError(f"Duplicate image IDs in {split}.txt")
    image_dir = root / ("JPEGImages-test" if split == "test" else "JPEGImages-trainval")
    xml_dir = root / "Annotations" / "Horizontal Bounding Boxes"
    label_ids = {name: i for i, name in enumerate(CLASSES)}
    images, annotations = [], []
    skipped = Counter()

    for image_id, stem in enumerate(ids, start=1):
        image_file = image_dir / f"{stem}.jpg"
        xml_file = xml_dir / f"{stem}.xml"
        if not image_file.is_file() or not xml_file.is_file():
            raise FileNotFoundError(f"Missing DIOR image or HBB XML for {stem}: {image_file}, {xml_file}")
        tree = ET.parse(xml_file).getroot()
        width = int(tree.findtext("size/width"))
        height = int(tree.findtext("size/height"))
        if width <= 0 or height <= 0:
            raise ValueError(f"Invalid image size in {xml_file}")
        images.append({"id": image_id, "file_name": image_file.name,
                       "width": width, "height": height})
        for obj in tree.findall("object"):
            name = obj.findtext("name")
            if name not in label_ids:
                raise ValueError(f"Unknown DIOR class {name!r} in {xml_file}")
            box = obj.find("bndbox")
            if box is None:
                raise ValueError(f"Missing horizontal bndbox in {xml_file}")
            x1, y1, x2, y2 = (float(box.findtext(tag)) for tag in
                              ("xmin", "ymin", "xmax", "ymax"))
            x1, x2 = max(0.0, x1), min(float(width), x2)
            y1, y2 = max(0.0, y1), min(float(height), y2)
            if x2 <= x1 or y2 <= y1:
                skipped["invalid_or_outside_box"] += 1
                continue
            annotations.append({
                "id": len(annotations) + 1, "image_id": image_id,
                "category_id": label_ids[name], "bbox": [x1, y1, x2 - x1, y2 - y1],
                "area": (x2 - x1) * (y2 - y1), "iscrowd": 0,
            })

    payload = {
        "info": {"description": f"DIOR horizontal bounding boxes: {split}"},
        "licenses": [], "images": images, "annotations": annotations,
        "categories": [{"id": i, "name": name} for i, name in enumerate(CLASSES)],
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, separators=(",", ":")), encoding="utf-8")
    return {"images": len(images), "annotations": len(annotations), "skipped": dict(skipped)}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path,
                        default=Path("/media/q/data2/ys/data/OpenDataLab___DIOR/raw/DIOR"))
    parser.add_argument("--output-dir", type=Path,
                        default=Path(__file__).resolve().parents[2] / "data" / "dior" / "annotations")
    args = parser.parse_args()
    train = (args.root / "ImageSets/Main/train.txt").read_text().split()
    val = (args.root / "ImageSets/Main/val.txt").read_text().split()
    test = (args.root / "ImageSets/Main/test.txt").read_text().split()
    if set(train) & set(val) or (set(train) | set(val)) & set(test):
        raise ValueError("DIOR train/val/test splits overlap")
    for split in ("train", "val", "test"):
        stats = convert_split(args.root, split, args.output_dir / f"{split}.json")
        print(f"{split}: {stats}")
    # Official DIOR training protocol uses both train and val images.
    trainval_file = args.output_dir / "trainval.json"
    split_file = args.root / "ImageSets/Main/trainval.txt"
    if split_file.exists():
        stats = convert_split(args.root, "trainval", trainval_file)
    else:
        # The OpenDataLab archive has no trainval.txt; create the union without
        # writing to the read-only source dataset.
        # Build from the two already converted split files to avoid a second
        # pass over more than 11,000 XML files.
        a = json.loads((args.output_dir / "train.json").read_text())
        b = json.loads((args.output_dir / "val.json").read_text())
        image_offset = len(a["images"])
        ann_offset = len(a["annotations"])
        for image in b["images"]:
            image["id"] += image_offset
        for ann in b["annotations"]:
            ann["id"] += ann_offset
            ann["image_id"] += image_offset
        a["images"].extend(b["images"])
        a["annotations"].extend(b["annotations"])
        a["info"]["description"] = "DIOR horizontal bounding boxes: trainval"
        trainval_file.write_text(json.dumps(a, separators=(",", ":")), encoding="utf-8")
        stats = {"images": len(a["images"]), "annotations": len(a["annotations"])}
    print(f"trainval: {stats}")


if __name__ == "__main__":
    main()
