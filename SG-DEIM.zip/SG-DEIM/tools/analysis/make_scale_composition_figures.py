"""Export panel (d) alone, and a matching version adding COCO2017 train.

Reuse the original four datasets' exact saved native-coordinate arrays. Compute
COCO with the same box clipping, flag filters and equivalent-side definition.
"""

import argparse
import csv
import json
from pathlib import Path
import zipfile

from make_dataset_figures import (
    ROOT, SCALE_BINS, SCALE_BIN_LABELS, checksum, configure_fonts, dump_json,
    export, np, plt, read_dataset, scale_composition_axes,
)


def load_original_datasets(folder):
    manifest_path = folder / 'manifest.json'
    arrays_path = folder / 'statistical_arrays.npz'
    manifest = json.loads(manifest_path.read_text())
    datasets = []
    with np.load(arrays_path) as arrays:
        for entry, stats in zip(manifest['datasets'], manifest['statistics']):
            source = entry['source']
            scales = arrays[f'{source["key"]}_scales'].copy()
            assert len(scales) == stats['instances']
            assert np.median(scales) == stats['median_scale_px']
            datasets.append(dict(source=source, scales=scales,
                                 bins=np.histogram(scales, bins=SCALE_BINS)[0],
                                 stats=stats, provenance=entry))
    return datasets, dict(manifest=str(manifest_path),
                         manifest_sha256=checksum(manifest_path),
                         statistical_arrays=str(arrays_path),
                         statistical_arrays_sha256=checksum(arrays_path))


def make_figure(datasets, output, stem):
    fig, ax = plt.subplots(figsize=(6.8, 4.5))
    scale_composition_axes(ax, datasets, title='')
    fig.subplots_adjust(left=.12, right=.985, bottom=.145, top=.965)
    export(fig, output, stem, svg=True, dpi=600)


def main(args):
    configure_fonts()
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    datasets, provenance = load_original_datasets(Path(args.original).resolve())
    make_figure(datasets, output, 'native_scale_composition_4datasets')
    source = json.loads(Path(args.coco_source).read_text())
    print('Reading COCO training annotations:', source['annotations'], flush=True)
    coco = read_dataset(source)
    coco['provenance'] = dict(source=source, annotation_sha256=checksum(source['annotations']),
                              excluded=coco['excluded'], clipped_boxes=coco['clipped_boxes'],
                              raw_annotations=coco['raw_annotations'])
    print('COCO statistics:', coco['stats'], flush=True)
    datasets.append(coco)
    make_figure(datasets, output, 'native_scale_composition_5datasets_coco')

    rows = []
    for dataset in datasets:
        counts = dataset['bins']
        total = len(dataset['scales'])
        assert counts.sum() == total
        proportions = counts / total * 100
        assert np.isclose(proportions.sum(), 100)
        for label, count, percent in zip(SCALE_BIN_LABELS, counts, proportions):
            rows.append(dict(dataset=dataset['source']['name'], scale_bin=label,
                             instances=int(count), percent=float(percent),
                             total_valid_instances=total))
    with (output / 'scale_composition.csv').open('w', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    with (output / 'dataset_summary.csv').open('w', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=list(datasets[0]['stats']))
        writer.writeheader()
        writer.writerows(d['stats'] for d in datasets)
    np.savez_compressed(output / 'coco_statistical_arrays.npz',
                        scales=coco['scales'], relative=coco['relative'], counts=coco['counts'])
    caption = ('Native-resolution object-scale composition of the local training splits. '
               'Equivalent side length is defined as s = sqrt(w h), using bounding boxes '
               'clipped to the original image boundaries. Bins are [0,16), [16,32), '
               '[32,96), and [96,infinity) pixels. Ignored, crowd, uncertain, and logo '
               'annotations are excluded. TinyPerson is measured before overlapping-patch '
               'extraction. Percentages are computed within each dataset. These common '
               'bounding-box scale bins are descriptive and do not replace official '
               'dataset-specific AP size definitions.')
    dump_json(output / 'manifest.json', dict(
        split='train', original_four_datasets=provenance,
        datasets=[d['provenance'] for d in datasets],
        statistics=[d['stats'] for d in datasets],
        scale_definition='sqrt(clipped bbox width * clipped bbox height)',
        bins_left_closed_right_open=['[0,16)', '[16,32)', '[32,96)', '[96,infinity)'],
        font='Comic Sans MS', png_dpi=600, figure_title='', caption_en=caption))
    coco_percent = coco['bins'] / len(coco['scales']) * 100
    original_ai = next(d for d in datasets if d['source']['key'] == 'aitod')
    original_tiny = next(d for d in datasets if d['source']['key'] == 'tinyperson')
    lines = [
        '# 图 (d) 单独原图及加入 COCO 的版本', '',
        '- `native_scale_composition_4datasets`：原图 (d) 单独导出，四数据集数值、配色和字体与之前一致。',
        '- `native_scale_composition_5datasets_coco`：保留原四数据集，加入 COCO2017 训练集。',
        '- 每张均提供 600 dpi PNG、矢量 PDF/SVG 以及预览 JPG。', '',
        '## 统计口径', '',
        '采用本地训练划分的原生分辨率标注，以边界裁剪后的检测框计算 `s=sqrt(w*h)`。'
        '四档为 `[0,16)`、`[16,32)`、`[32,96)`、`[96,+∞)` px。'
        '剔除 ignore、iscrowd、uncertain、logo 及非正面积框。'
        'TinyPerson 采用重叠切片前原图。分母为每个数据集各自的有效目标总数。', '',
        '本图使用检测框面积；COCO 官方 AP 尺度分组使用标注 area，因此这些比例不应直接当作官方 AP_S/AP_M/AP_L 的实例占比。', '',
        '| 数据集 | <16 px | 16–32 px | 32–96 px | ≥96 px |',
        '| --- | ---: | ---: | ---: | ---: |',
    ]
    for dataset in datasets:
        values = dataset['bins'] / len(dataset['scales']) * 100
        lines.append('| ' + dataset['source']['name'] + ' | '
                     + ' | '.join(f'{value:.2f}%' for value in values) + ' |')
    lines += ['', '## 加入 COCO 后的简要分析', '',
              f'COCO2017 train 包含 {coco["stats"]["images"]:,} 张图像，过滤后有 '
              f'{coco["stats"]["instances"]:,} 个有效检测框。'
              f'小于 16 px 的目标占 {coco_percent[0]:.2f}%，'
              f'小于 32 px 的目标占 {coco_percent[:2].sum():.2f}%。'
              f'相比之下，AI-TODv1 和 TinyPerson 中小于 32 px 的比例分别为 '
              f'{original_ai["stats"]["below32_percent"]:.2f}% 和 '
              f'{original_tiny["stats"]["below32_percent"]:.2f}%。'
              '这一对比说明，COCO 可用于考察通用多尺度检测能力，AI-TODv1 和 TinyPerson '
              '则提供更集中于微小目标的评测场景。图中尺度分布可作为研究动机，模块效果仍需结合消融结果。', '',
              '## 英文图注', '', caption, '', '## 复现', '', '```bash',
              '/home/user1/anaconda3/envs/deimv2/bin/python tools/analysis/make_scale_composition_figures.py',
              '```', '']
    (output / 'README.md').write_text('\n'.join(lines))
    archive = output.with_suffix('.zip')
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as bundle:
        for path in sorted(output.iterdir()):
            if path.is_file():
                bundle.write(path, path.name)
    print('Output:', output, flush=True)
    print('Archive:', archive, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--original', default=ROOT / 'outputs/visualizations/SG-DEIM_dataset_overview')
    parser.add_argument('--coco-source', default=ROOT / 'configs/visualization/coco_scale_source.json')
    parser.add_argument('-o', '--output', default=ROOT / 'outputs/visualizations/SG-DEIM_dataset_scale_composition')
    main(parser.parse_args())
