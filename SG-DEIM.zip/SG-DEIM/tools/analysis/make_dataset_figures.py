"""Create paper figures from the four local training annotation sets.

No model inference is involved. Cyan boxes in the image figure are ground truth.
All statistics use native-image coordinates before resizing or patch extraction.
"""

import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import zipfile

os.environ.setdefault('MPLCONFIGDIR', '/tmp/sg-deim-matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
from matplotlib.ticker import FuncFormatter
import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
GT_COLOR = '#00E5FF'
ROI_COLOR = '#FFB000'
CROP_SIZE = 192
SCALE_BINS = [0, 16, 32, 96, np.inf]
SCALE_BIN_LABELS = ['<16 px', '16-32 px', '32-96 px', '>=96 px']
SCALE_BIN_COLORS = ['#D6EAF5', '#94C4DF', '#427FA9', '#173F63']


def dump_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def checksum(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as file:
        for chunk in iter(lambda: file.read(1024 * 1024), b''):
            result.update(chunk)
    return result.hexdigest()


def configure_fonts():
    for name in ('Comic.TTF', 'Comicbd.TTF'):
        font_manager.fontManager.addfont(str(ROOT / 'assets/fonts/comic_sans_ms' / name))
    plt.rcParams.update({
        'font.family': 'Comic Sans MS', 'font.size': 11,
        'axes.titlesize': 13, 'axes.titleweight': 'bold', 'axes.labelsize': 11,
        'xtick.labelsize': 10, 'ytick.labelsize': 10,
        'axes.spines.top': False, 'axes.spines.right': False,
        'pdf.fonttype': 42, 'svg.fonttype': 'path',
        'savefig.facecolor': 'white',
    })


def read_dataset(source):
    raw = json.loads(Path(source['annotations']).read_text())
    images = {image['id']: image for image in raw['images']}
    names = {category['id']: category['name'] for category in raw['categories']}
    if source.get('merge_to_person'):
        names = {0: 'person'}
    by_image = defaultdict(list)
    scales, relative, categories = [], [], []
    excluded, clipped = Counter(), 0
    for original in raw['annotations']:
        if any(original.get(key, False) for key in ('ignore', 'iscrowd', 'uncertain', 'logo')):
            excluded['flagged'] += 1
            continue
        image = images[original['image_id']]
        x, y, w, h = map(float, original['bbox'])
        W, H = image['width'], image['height']
        x1, y1 = max(0., min(W, x)), max(0., min(H, y))
        x2, y2 = max(0., min(W, x + w)), max(0., min(H, y + h))
        if x2 <= x1 or y2 <= y1:
            excluded['nonpositive_after_clipping'] += 1
            continue
        clipped += int((x1, y1, x2, y2) != (x, y, x + w, y + h))
        w, h = x2 - x1, y2 - y1
        category = 0 if source.get('merge_to_person') else original['category_id']
        assert category in names
        scale = math.sqrt(w * h)
        annotation = dict(id=original['id'], image_id=original['image_id'],
                          category_id=category, bbox=[x1, y1, w, h], scale=scale)
        by_image[image['id']].append(annotation)
        scales.append(scale)
        relative.append(100 * math.sqrt(w * h / (W * H)))
        categories.append(category)
    scales = np.asarray(scales, dtype=np.float64)
    relative = np.asarray(relative, dtype=np.float64)
    counts = np.asarray([len(by_image[i]) for i in images], dtype=np.int32)
    category_counts = Counter(categories)
    bins = np.histogram(scales, bins=SCALE_BINS)[0]
    assert counts.sum() == len(scales) == sum(category_counts.values()) == bins.sum()
    assert np.isfinite(scales).all() and np.isfinite(relative).all()
    stats = dict(dataset=source['name'], images=len(images), instances=len(scales),
                 classes=len(names), median_scale_px=float(np.median(scales)),
                 mean_scale_px=float(np.mean(scales)),
                 q25_scale_px=float(np.quantile(scales, .25)),
                 q75_scale_px=float(np.quantile(scales, .75)),
                 below16_percent=float(np.mean(scales < 16) * 100),
                 below32_percent=float(np.mean(scales < 32) * 100),
                 median_relative_scale_percent=float(np.median(relative)),
                 mean_instances_per_image=float(np.mean(counts)),
                 median_instances_per_image=float(np.median(counts)),
                 p90_instances_per_image=float(np.quantile(counts, .9)),
                 max_instances_per_image=int(counts.max()),
                 empty_images=int(np.sum(counts == 0)))
    return dict(source=source, images=images, by_image=by_image, names=names,
                scales=scales, relative=relative, counts=counts,
                category_counts=category_counts, bins=bins, stats=stats,
                raw_annotations=len(raw['annotations']), excluded=dict(excluded),
                clipped_boxes=clipped)


def export(fig, output, stem, svg=False, dpi=300):
    fig.savefig(output / f'{stem}.png', dpi=dpi)
    fig.savefig(output / f'{stem}.pdf', dpi=dpi)
    if svg:
        fig.savefig(output / f'{stem}.svg')
    plt.close(fig)
    with Image.open(output / f'{stem}.png') as image:
        preview = image.convert('RGB')
        preview.thumbnail((1600, 1500))
        preview.save(output / f'{stem}_preview.jpg', quality=94)


def ecdf(values):
    values = np.sort(values)
    indices = np.unique(np.linspace(0, len(values) - 1, min(3000, len(values))).round().astype(int))
    return values[indices], 100 * (indices + 1) / len(values)


def scale_composition_axes(ax, datasets, title='(d) Native scale composition'):
    """Draw the original panel (d), with any number of datasets."""
    size = len(datasets)
    proportions = np.asarray([d['bins'] / len(d['scales']) * 100 for d in datasets])
    bottom = np.zeros(size)
    for index, (label, color) in enumerate(zip(SCALE_BIN_LABELS, SCALE_BIN_COLORS)):
        values = proportions[:, index]
        ax.bar(np.arange(size), values, bottom=bottom, width=.65,
               label=label, color=color, edgecolor='white', linewidth=1)
        for x, value, base in zip(range(size), values, bottom):
            if value >= 7:
                ax.text(x, base + value / 2, f'{value:.1f}', ha='center', va='center',
                        fontsize=9.5, color='white' if index > 1 else '#111111')
        bottom += values
    ax.set_ylim(0, 130)
    ax.set_yticks([0, 25, 50, 75, 100])
    ax.set_xticks(range(size), [d['source']['name'] for d in datasets], fontsize=9.5)
    ax.set_ylabel('Instances (%)')
    ax.set_title(title, loc='left')
    ax.legend(loc='upper center', ncol=2, fontsize=9.5, frameon=False, columnspacing=1.2)
    ax.grid(True, axis='y', color='#DDDDDD', lw=.7, alpha=.8)
    ax.set_axisbelow(True)


def statistics_figure(datasets, output):
    fig, axes = plt.subplots(2, 2, figsize=(11.8, 8.1))
    styles = ['-', '--', '-.', ':']
    for dataset, style in zip(datasets, styles):
        source = dataset['source']
        for ax, key in zip(axes.flat[:3], ('scales', 'relative', 'counts')):
            x, y = ecdf(dataset[key])
            ax.plot(x, y, color=source['color'], linestyle=style, lw=2.15, label=source['name'])
    for ax in axes.flat[:3]:
        ax.set_ylim(0, 102)
        ax.set_yticks([0, 25, 50, 75, 100])
        ax.grid(True, which='major', color='#DDDDDD', lw=.7, alpha=.8)
        ax.set_axisbelow(True)
    ax = axes[0, 0]
    ax.set_xscale('log', base=2)
    ax.set_xlim(min(.8, min(d['scales'].min() for d in datasets)), 1200)
    ax.set_xticks([1, 4, 16, 64, 256, 1024])
    ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _: f'{v:g}'))
    for value in (16, 32):
        ax.axvline(value, color='#888888', lw=.8, linestyle=':', zorder=0)
    ax.set_title('(a) Native object scale', loc='left')
    ax.set_xlabel('Equivalent side length (pixels)')
    ax.set_ylabel('Instances, cumulative (%)')
    ax = axes[0, 1]
    ax.set_xscale('log')
    ax.set_xlim(min(.05, min(d['relative'].min() for d in datasets)), 100)
    ax.set_xticks([.1, .5, 1, 5, 10, 50, 100])
    ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _: f'{v:g}'))
    ax.set_title('(b) Relative object scale', loc='left')
    ax.set_xlabel('Normalized equivalent side length (%)')
    ax.set_ylabel('Instances, cumulative (%)')
    ax = axes[1, 0]
    ax.set_xscale('symlog', linthresh=1)
    ax.set_xlim(0, max(d['counts'].max() for d in datasets) * 1.15)
    ax.set_xticks([0, 1, 10, 100, 1000])
    ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _: f'{v:g}'))
    ax.set_title('(c) Objects per original image', loc='left')
    ax.set_xlabel('Number of valid instances')
    ax.set_ylabel('Images, cumulative (%)')
    scale_composition_axes(axes[1, 1], datasets)
    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, loc='upper center', bbox_to_anchor=(.52, 1.005),
               ncol=4, frameon=False, fontsize=12, handlelength=3)
    fig.subplots_adjust(left=.08, right=.985, bottom=.09, top=.91, wspace=.25, hspace=.38)
    export(fig, output, 'dataset_statistics', svg=True)


def choose_roi(dataset, image, annotations):
    preferred = set(dataset['source']['preferred_crop_classes'])
    small = [a for a in annotations if a['category_id'] in preferred and a['scale'] < 32]
    if not small:
        small = sorted(annotations, key=lambda a: a['scale'])[:max(1, len(annotations) // 2)]
    ranked = []
    for annotation in small:
        x, y, w, h = annotation['bbox']
        left = int(max(0, min(image['width'] - CROP_SIZE, x + w / 2 - CROP_SIZE / 2)))
        top = int(max(0, min(image['height'] - CROP_SIZE, y + h / 2 - CROP_SIZE / 2)))
        contained = [a for a in small if left <= a['bbox'][0] + a['bbox'][2] / 2 < left + CROP_SIZE
                     and top <= a['bbox'][1] + a['bbox'][3] / 2 < top + CROP_SIZE]
        score = len(contained) - .01 * abs(np.median([a['scale'] for a in contained]) - 12)
        ranked.append((score, left, top))
    _, left, top = max(ranked)
    return [left, top, left + CROP_SIZE, top + CROP_SIZE]


def examples_figure(datasets, output):
    fig = plt.figure(figsize=(12.8, 6.7))
    grid = fig.add_gridspec(2, 4, left=.025, right=.985, bottom=.08, top=.88,
                            wspace=.035, hspace=.16, height_ratios=[.75, 1])
    selected = []
    (output / 'sample_originals').mkdir(exist_ok=True)
    (output / 'sample_crops').mkdir(exist_ok=True)
    for index, dataset in enumerate(datasets):
        source = dataset['source']
        meta = next(im for im in dataset['images'].values() if im['file_name'] == source['sample'])
        path = Path(source['images']) / meta['file_name']
        image = Image.open(path).convert('RGB')
        assert image.size == (meta['width'], meta['height'])
        annotations = dataset['by_image'][meta['id']]
        roi = choose_roi(dataset, meta, annotations)
        left, top, right, bottom = roi
        crop = image.crop(tuple(roi))
        crop.save(output / 'sample_crops' / f'{source["key"]}_192px.png')
        original_copy = Path('sample_originals') / f'{source["key"]}__{path.name}'
        shutil.copy2(path, output / original_copy)
        ax = fig.add_subplot(grid[0, index])
        ax.imshow(image, interpolation='nearest')
        W, H = image.size
        view_w, view_h = max(W, H * 4 / 3), max(H, W * 3 / 4)
        pad_x, pad_y = (view_w - W) / 2, (view_h - H) / 2
        ax.set_xlim(-pad_x, W + pad_x)
        ax.set_ylim(H + pad_y, -pad_y)
        for annotation in annotations:
            x, y, w, h = annotation['bbox']
            ax.add_patch(Rectangle((x, y), w, h, fill=False, ec=GT_COLOR, lw=.65))
        ax.add_patch(Rectangle((left, top), CROP_SIZE, CROP_SIZE, fill=False, ec=ROI_COLOR, lw=1.8))
        ax.set_title(f'({chr(97+index)}) {source["name"]}\n{source["description"]}', fontsize=12)
        ax.text(.5, -.04, f'{len(annotations)} instances | median s = {np.median([a["scale"] for a in annotations]):.1f} px',
                transform=ax.transAxes, fontsize=9, va='top', ha='center')
        ax.axis('off')
        ax = fig.add_subplot(grid[1, index])
        ax.imshow(crop, interpolation='nearest')
        crop_count = 0
        for annotation in annotations:
            x, y, w, h = annotation['bbox']
            x1, y1, x2, y2 = max(left, x), max(top, y), min(right, x + w), min(bottom, y + h)
            if x2 > x1 and y2 > y1:
                ax.add_patch(Rectangle((x1-left, y1-top), x2-x1, y2-y1, fill=False, ec=GT_COLOR, lw=1))
                crop_count += 1
        ax.set_xlim(-.5, CROP_SIZE - .5)
        ax.set_ylim(CROP_SIZE - .5, -.5)
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_visible(True)
            spine.set_color(ROI_COLOR)
            spine.set_linewidth(1.6)
        ax.set_xlabel('192 x 192 native-pixel detail', fontsize=10)
        selected.append(dict(dataset=source['name'], file_name=meta['file_name'], image_id=meta['id'],
                             source=str(path), source_sha256=checksum(path),
                             original_copy=str(original_copy), native_size=[W,H], roi_xyxy=roi,
                             valid_instances=len(annotations), crop_intersecting_boxes=crop_count))
    handles = [Line2D([0], [0], color=GT_COLOR, lw=2, label='Ground-truth boxes'),
               Line2D([0], [0], color=ROI_COLOR, lw=2, label='Zoom region')]
    fig.legend(handles=handles, loc='upper center', bbox_to_anchor=(.5, 1.005),
               frameon=False, ncol=2, fontsize=12)
    export(fig, output, 'dataset_examples')
    return selected


def category_figures(datasets, output):
    folder = output / 'class_frequency'
    folder.mkdir(exist_ok=True)
    for dataset in datasets:
        source = dataset['source']
        categories = sorted(dataset['category_counts'], key=lambda c: -dataset['category_counts'][c])
        values = [100 * dataset['category_counts'][c] / len(dataset['scales']) for c in categories]
        labels = [dataset['names'][c] for c in categories]
        fig, ax = plt.subplots(figsize=(7.6, max(2.4, .29 * len(categories) + 1.2)))
        ax.barh(np.arange(len(categories)), values, color=source['color'], height=.66)
        ax.set_yticks(np.arange(len(categories)), labels, fontsize=10)
        ax.invert_yaxis()
        ax.set_xlim(0, min(112, max(values) * 1.2 + 2))
        ax.set_xlabel('Share of valid instances (%)')
        ax.set_title(source['name'] + ' | training class distribution', loc='left')
        for y, value in enumerate(values):
            ax.text(value + .5, y, f'{value:.1f}%', va='center', fontsize=9.5)
        ax.grid(axis='x', alpha=.25)
        ax.set_axisbelow(True)
        fig.subplots_adjust(left=.32, right=.98, top=.90, bottom=.18 if len(categories)<5 else .12)
        export(fig, folder, source['key'], svg=True)


def write_report(datasets, selected, output):
    stats = {d['source']['key']: d['stats'] for d in datasets}
    vis, ai, tiny, dior = [stats[key] for key in ('visdrone','aitod','tinyperson','dior')]
    captions = {
        'examples': 'Representative training scenes and local details from VisDrone2019, AI-TODv1, TinyPerson, and DIOR. Cyan rectangles denote valid ground-truth boxes; orange rectangles identify the zoomed regions. Every local detail uses a 192 x 192 crop in native-image coordinates and nearest-neighbor display. The examples illustrate UAV clutter, aerial tiny objects, long-range pedestrians, and within-scene scale variation.',
        'statistics': 'Comparison of the local training annotations at native resolution. (a) Cumulative distributions of equivalent object side length s = sqrt(w h). (b) Cumulative distributions of normalized scale, 100 sqrt(w h / (W H)), where W and H are image dimensions. (c) Distributions of valid instances per original image. (d) Instance fractions in shared scale bins. Ignored, crowd, uncertain, and logo annotations are excluded. TinyPerson is counted before overlapping-patch extraction. Scale bins are descriptive common thresholds rather than replacements for dataset-specific AP protocols.',
    }
    dump_json(output / 'captions_en.json', captions)
    lines = [
        '# 四数据集论文插图与简要分析', '',
        '建议正文优先采用两张图：`dataset_examples.pdf` 放在 4.1 Datasets；`dataset_statistics.pdf` 放在数据集介绍后或研究动机部分。`class_frequency/` 的各数据集类别分布图可用于附录。', '',
        '## 统计口径', '',
        '- 全部数字由当前项目使用的本地训练标注重新计算；不是全数据集官方总量。',
        '- 尺度 `s=sqrt(w*h)`，单位为原生图像像素；相对尺度 `r=100*sqrt(w*h/(W*H))`。',
        '- 在图像边界处裁剪框，剔除非正面积以及 ignore、iscrowd、uncertain、logo 标注；每图目标数包含无有效目标的原图。',
        '- TinyPerson 采用重叠切片前的 746 张训练原图；sea_person 和 earth_person 合并为检测器的单一 person 类。不能把训练切片中的重复目标当作独立原始实例。',
        '- DIOR 采用当前训练配置的 train 划分（5,862 张），不是 train+val。',
        '- 样例框均为 ground truth，仅用于展示数据特点；不是模型检测结果。',
        '- 示例按语义与场景特点人工选择；统计分布来自全部有效训练标注，而非四张示例。', '',
        '## 数字概要', '',
        '| 数据集 | 训练原图 | 有效实例 | 检测类别 | 尺度中位数/px | s<16 比例 | 每图平均实例 | 相对尺度中位数 |',
        '| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |',
    ]
    for dataset in datasets:
        s=dataset['stats']
        lines.append(f'| {s["dataset"]} | {s["images"]:,} | {s["instances"]:,} | {s["classes"]} | {s["median_scale_px"]:.2f} | {s["below16_percent"]:.2f}% | {s["mean_instances_per_image"]:.2f} | {s["median_relative_scale_percent"]:.3f}% |')
    lines += [
        '', '## 简要分析', '',
        f'1. **VisDrone2019：密集且背景复杂。** 每图平均有 {vis["mean_instances_per_image"]:.2f} 个有效目标，中位数 {vis["median_instances_per_image"]:.0f} 个。拥挤与道路、建筑纹理的并存，可作为跨尺度融合与查询更新需要抑制干扰的研究动机。',
        f'2. **AI-TODv1：绝对像素尺寸最小。** 尺度中位数 {ai["median_scale_px"]:.2f} px，{ai["below16_percent"]:.2f}% 的实例小于 16 px。每图实例数中位数仅 {ai["median_instances_per_image"]:.0f}、最大 {ai["max_instances_per_image"]}，呈明显长尾，不能只用平均值概括拥挤程度。',
        f'3. **TinyPerson：相对尺度更小。** 中位等效尺度为 {tiny["median_scale_px"]:.2f} px，而相对尺度中位数仅 {tiny["median_relative_scale_percent"]:.3f}%，低于 AI-TODv1 的 {ai["median_relative_scale_percent"]:.3f}%。大幅原图中的远距离行人可为保留微弱局部证据提供直观说明。',
        f'4. **DIOR：跨尺度与类别多样性更强。** 有 20 个检测类别，尺度四分位区间为 {dior["q25_scale_px"]:.2f}–{dior["q75_scale_px"]:.2f} px，较 AI-TODv1 的 {ai["q25_scale_px"]:.2f}–{ai["q75_scale_px"]:.2f} px 更宽；适合展示多尺度交互的适用范围。',
        '', '这些图说明数据特征，可分别联系 CGSR 的细节保留、CSAI 的跨尺度交互以及 QCAG 的密集场景响应筛选。模块有效性需结合论文的消融与 AP 结果论证。', '',
        '## 类别分布补充', '',
    ]
    for dataset in datasets:
        category, count = dataset['category_counts'].most_common(1)[0]
        lines.append(f'- {dataset["source"]["name"]}：{dataset["names"][category]} 占有效实例的 {count/len(dataset["scales"])*100:.2f}%。')
    lines += ['', 'TinyPerson 本身是单类检测，person 占 100% 不应被解读为多类别不平衡。', '',
              '## 英文图注（可直接改入论文）', '', captions['examples'], '', captions['statistics'], '',
              '## 可用于论文的英文分析段落', '',
              f'The four benchmarks exhibit complementary scale and density characteristics. In our training annotations, {ai["below16_percent"]:.1f}% of AI-TODv1 instances have an equivalent side length below 16 pixels, whereas VisDrone2019 contains {vis["mean_instances_per_image"]:.1f} valid instances per image on average. TinyPerson has the smallest median normalized object scale ({tiny["median_relative_scale_percent"]:.2f}%), while DIOR covers 20 categories and a substantially wider native-scale range. These differences motivate evaluating fine-detail preservation, cross-scale interaction, and query-update regulation across diverse small-object conditions.', '',
              '## 与当前 PDF 的衔接', '',
              '所提供 SG-DEIM.pdf 的 4.1 目前列的是 VisDrone2019、COCO、AI-TODv1、TinyPerson，尚未介绍 DIOR。本次图按你指定的 VisDrone2019、AI-TODv1、TinyPerson、DIOR 制作；新增 DIOR 实验时可同步补充数据集介绍。若继续保留 COCO，应在图注中说明这只是所展示的四个数据集，不把它们误称为全部实验数据集。', '',
              '## 数据来源与官方说明', '']
    for dataset in datasets:
        source=dataset['source']
        lines.append(f'- [{source["name"]}]({source["reference"]})；本地标注：`{source["annotations"]}`。')
    lines += ['', '## 复现', '', '```bash',
              '/home/user1/anaconda3/envs/deimv2/bin/python tools/analysis/make_dataset_figures.py',
              '```', '', 'PNG 为 300 dpi；PDF 嵌入 Comic Sans MS 字体。统计图另提供 SVG。完整统计见 CSV，图示源图与 192 像素裁剪均单独提供。', '']
    (output/'analysis.md').write_text('\n'.join(lines))
    tex = r'''% Copy the figure files into the manuscript's figure directory.
\begin{figure*}[t]
  \centering
  \includegraphics[width=\textwidth]{dataset_examples.pdf}
  \caption{Representative training scenes from VisDrone2019, AI-TODv1, TinyPerson, and DIOR. Cyan boxes denote valid ground truth and orange rectangles mark the zoom regions. Local views use $192\times192$ native-pixel crops.}
  \label{fig:dataset_examples}
\end{figure*}

\begin{figure*}[t]
  \centering
  \includegraphics[width=\textwidth]{dataset_statistics.pdf}
  \caption{Native-resolution training-set statistics: (a) equivalent side length $s=\sqrt{wh}$; (b) normalized scale $100\sqrt{wh/(WH)}$; (c) instances per original image; and (d) shared scale bins. Ignored, crowd, uncertain, and logo regions are excluded. TinyPerson is measured before overlapping-patch extraction.}
  \label{fig:dataset_statistics}
\end{figure*}
'''
    (output/'paper_figures.tex').write_text(tex)


def main(args):
    configure_fonts()
    sources=json.loads(Path(args.sources).read_text())
    output=Path(args.output).resolve()
    output.mkdir(parents=True,exist_ok=True)
    datasets=[]
    for source in sources:
        dataset=read_dataset(source)
        datasets.append(dataset)
        print(source['name'],dataset['stats'],flush=True)
    summary=[d['stats'] for d in datasets]
    with (output/'dataset_summary.csv').open('w',newline='') as file:
        writer=csv.DictWriter(file,fieldnames=list(summary[0]))
        writer.writeheader();writer.writerows(summary)
    with (output/'class_frequency.csv').open('w',newline='') as file:
        writer=csv.writer(file);writer.writerow(['dataset','category_id','category','instances','percent'])
        for dataset in datasets:
            for category,count in dataset['category_counts'].most_common():
                writer.writerow([dataset['source']['name'],category,dataset['names'][category],count,100*count/len(dataset['scales'])])
    arrays={}
    for dataset in datasets:
        for field in ('scales','relative','counts'):
            arrays[f'{dataset["source"]["key"]}_{field}']=dataset[field]
    np.savez_compressed(output/'statistical_arrays.npz',**arrays)
    statistics_figure(datasets,output)
    selected=examples_figure(datasets,output)
    category_figures(datasets,output)
    dump_json(output/'selected_examples.json',selected)
    manifest=dict(split='train',coordinates='native original images, before model resizing',
                  instance_filter='clip boxes to image; positive area; ignore/iscrowd/uncertain/logo excluded',
                  scale_definition='sqrt(w*h)',normalized_scale_definition='100*sqrt(w*h/(W*H))',
                  displayed_boxes='ground truth',crop_size=[CROP_SIZE,CROP_SIZE],
                  font='Comic Sans MS',statistics=summary,
                  datasets=[dict(source=d['source'],annotation_sha256=checksum(d['source']['annotations']),
                                 excluded=d['excluded'],clipped_boxes=d['clipped_boxes'],
                                 raw_annotations=d['raw_annotations']) for d in datasets])
    dump_json(output/'manifest.json',manifest)
    write_report(datasets,selected,output)
    archive=output.parent/f'{output.name}.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as bundle:
        for path in sorted(output.rglob('*')):
            if path.is_file():bundle.write(path,arcname=str(path.relative_to(output)))
    print('Figures and report:',output,flush=True)
    print('Complete archive:',archive,flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sources',default='configs/visualization/dataset_overview_sources.json')
    parser.add_argument('-o','--output',default='outputs/visualizations/SG-DEIM_dataset_overview')
    main(parser.parse_args())
