"""Add readable class names to the existing 16-image DIOR visualization."""

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import sys
import zipfile

os.environ.setdefault('MPLCONFIGDIR', '/tmp/sg-deim-matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from matplotlib.patches import Rectangle
from PIL import Image, ImageDraw, ImageFont

REPO_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO_ROOT))
from tools.inference.visualize_dior import CLASS_STYLE, clipped_box, sha256, write_json

FONT_PATH = str(REPO_ROOT / 'assets/fonts/comic_sans_ms/Comicbd.TTF')
FONT_SIZE = 20
LEGEND_FONT_PT = 14
LEGEND_ROW_HEIGHT = 64
LEGEND_HEIGHT = 288


def intersection(a, b):
    return max(0, min(a[2], b[2]) - max(a[0], b[0])) * max(0, min(a[3], b[3]) - max(a[1], b[1]))


def label_layout(predictions, width=800, height=800):
    font = ImageFont.truetype(FONT_PATH, FONT_SIZE)
    boxes = [clipped_box(p['box_xyxy'], width, height) for p in predictions]
    placed = []
    occupied = [[0, 0, 80, 64]]  # Reserve the montage's panel letter and padding.
    order = sorted(range(len(predictions)), key=lambda i: -predictions[i]['score'])
    for index in order:
        pred = predictions[index]
        text = CLASS_STYLE[pred['category_id']][0]
        text_bounds = font.getbbox(text)
        tw = text_bounds[2] - text_bounds[0] + 8
        th = text_bounds[3] - text_bounds[1] + 8
        x1, y1, x2, y2 = boxes[index]
        candidates = [
            (x1, y1 - th - 2), (x2 - tw, y1 - th - 2),
            (x1, y2 + 2), (x2 - tw, y2 + 2),
            (x2 + 3, y1), (x1 - tw - 3, y1),
            (x1 + 2, y1 + 2), (x2 - tw - 2, y2 - th - 2),
        ]
        for shift in (1, 2, 3, 4, 5):
            for x in (x1, x2 - tw, x1 - tw - 3, x2 + 3,
                      x1 - tw * 1.5 - 3, x2 + tw * .5 + 3):
                candidates.extend([(x, y1 - (th + 3) * shift),
                                   (x, y2 + 3 + (th + 3) * (shift - 1))])
        ranked = []
        for rank, (left, top) in enumerate(candidates):
            left = max(2, min(width - tw - 2, left))
            top = max(2, min(height - th - 2, top))
            tag = [left, top, left + tw, top + th]
            collision = sum(intersection(tag, other) for other in occupied) / (tw * th)
            obscured = 0
            for other in boxes:
                area = max(1, (other[2] - other[0]) * (other[3] - other[1]))
                obscured += intersection(tag, other) / area
            center = (left + tw / 2, top + th / 2)
            anchor = (max(x1, min(x2, center[0])), max(y1, min(y2, center[1])))
            distance = abs(center[0] - anchor[0]) + abs(center[1] - anchor[1])
            cost = collision * 10000 + obscured * 120 + distance * .08 + rank * .002
            ranked.append((cost, tag, anchor))
        _, tag, anchor = min(ranked, key=lambda r: r[0])
        start = [max(tag[0], min(tag[2], anchor[0])), max(tag[1], min(tag[3], anchor[1]))]
        placed.append(dict(prediction_index=index, category_id=pred['category_id'],
                           text=text, tag_xyxy=tag, connector=[start, list(anchor)]))
        occupied.append(tag)
    return placed


def draw_individual(image, predictions, labels):
    result = image.copy()
    painter = ImageDraw.Draw(result)
    for pred in sorted(predictions, key=lambda p: (
            p['box_xyxy'][2] - p['box_xyxy'][0]) * (
                p['box_xyxy'][3] - p['box_xyxy'][1]), reverse=True):
        painter.rectangle(clipped_box(pred['box_xyxy'], *image.size),
                          outline=CLASS_STYLE[pred['category_id']][2], width=2)
    for item in labels:
        painter.line([tuple(p) for p in item['connector']],
                     fill=CLASS_STYLE[item['category_id']][2], width=1)
    font = ImageFont.truetype(FONT_PATH, FONT_SIZE)
    for item in labels:
        x1, y1, x2, y2 = item['tag_xyxy']
        painter.rectangle((x1, y1, x2, y2), fill='#151515',
                          outline=CLASS_STYLE[item['category_id']][2], width=1)
        bounds = font.getbbox(item['text'])
        painter.text((x1 + 4, y1 + 4 - bounds[1]), item['text'], font=font, fill='white')
    return result


def add_comic_legend(fig, class_ids, height, width):
    font = FontProperties(fname=FONT_PATH, weight='bold')
    cell_width = (width - 48) / 5
    for index, category_id in enumerate(class_ids):
        row, col = divmod(index, 5)
        x = 24 + col * cell_width
        center_y = LEGEND_HEIGHT - 20 - (row + .5) * LEGEND_ROW_HEIGHT
        color = CLASS_STYLE[category_id][2]
        text = CLASS_STYLE[category_id][0]
        fig.add_artist(Rectangle((x / width, (center_y - 12) / height),
                                 48 / width, 24 / height, transform=fig.transFigure,
                                 fill=False, edgecolor=color, linewidth=1.5))
        fig.text((x + 68) / width, center_y / height, text,
                 fontproperties=font, fontsize=LEGEND_FONT_PT,
                 va='center', color='#111111', wrap=False)


def bilingual_comic_legend(output, records):
    from collections import Counter
    counts = Counter(p['category_id'] for r in records for p in r['detections'])
    chinese_path = '/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'
    chinese = ImageFont.truetype(chinese_path, 28)
    detail = ImageFont.truetype(chinese_path, 22)
    english = ImageFont.truetype(FONT_PATH, 28)
    canvas = Image.new('RGB', (2200, 1120), 'white')
    painter = ImageDraw.Draw(canvas)
    painter.text((32, 20), 'DIOR 类别颜色图例 / ', font=chinese, fill='black')
    left = 32 + painter.textlength('DIOR 类别颜色图例 / ', font=chinese)
    painter.text((left, 20), 'Class color legend', font=english, fill='black')
    for index, (name, translation, color) in enumerate(CLASS_STYLE):
        col, row = divmod(index, 10)
        x, y = 36 + col * 1100, 91 + row * 100
        painter.rectangle((x, y + 9, x + 64, y + 43), outline=color, width=5)
        prefix = translation + ' / '
        painter.text((x + 88, y), prefix, font=chinese, fill='#111111')
        english_x = x + 88 + painter.textlength(prefix, font=chinese)
        painter.text((english_x, y), name, font=english, fill='#111111')
        painter.text((x + 88, y + 44), f'ID {index:02d}    {color}    检测框数量: {counts[index]}',
                     font=detail, fill='#555555')
    canvas.save(output / 'class_legend_bilingual.png')


def render_montage(records, layouts, output):
    tile, gap, margin, legend_height, dpi = 800, 8, 12, LEGEND_HEIGHT, 200
    width = tile * 4 + gap * 3 + margin * 2
    height = width + legend_height
    fig = plt.figure(figsize=(width / dpi, height / dpi), dpi=dpi, facecolor='white')
    font = FontProperties(fname=FONT_PATH)
    for index, (record, labels) in enumerate(zip(records, layouts)):
        row, col = divmod(index, 4)
        left, top = margin + col * (tile + gap), margin + row * (tile + gap)
        ax = fig.add_axes([left / width, (height - top - tile) / height, tile / width, tile / height])
        ax.imshow(Image.open(output / record['original_copy']).convert('RGB'), interpolation='none')
        ax.set_xlim(-.5, 799.5)
        ax.set_ylim(799.5, -.5)
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_linewidth(.35)
            spine.set_edgecolor('#888888')
        for pred in sorted(record['detections'], key=lambda p: (
                p['box_xyxy'][2] - p['box_xyxy'][0]) * (
                    p['box_xyxy'][3] - p['box_xyxy'][1]), reverse=True):
            x1, y1, x2, y2 = clipped_box(pred['box_xyxy'], 800, 800)
            ax.add_patch(Rectangle((x1, y1), x2 - x1, y2 - y1,
                                   fill=False, linewidth=.72, edgecolor=CLASS_STYLE[pred['category_id']][2]))
        for item in labels:
            start, end = item['connector']
            ax.plot([start[0], end[0]], [start[1], end[1]],
                    color=CLASS_STYLE[item['category_id']][2], linewidth=.36)
        for item in labels:
            x1, y1, x2, y2 = item['tag_xyxy']
            ax.add_patch(Rectangle((x1, y1), x2 - x1, y2 - y1,
                                   facecolor='#151515', edgecolor=CLASS_STYLE[item['category_id']][2],
                                   linewidth=.36, zorder=5))
            ax.text(x1 + 4, (y1 + y2) / 2, item['text'], color='white',
                    fontsize=FONT_SIZE * 72 / dpi, fontproperties=font, va='center', zorder=6)
        ax.text(.018, .978, record['panel'], transform=ax.transAxes, va='top', ha='left',
                fontsize=10.5, color='white', fontproperties=font, zorder=8,
                bbox=dict(facecolor='black', alpha=.65, edgecolor='none', pad=2.2))
    ids = sorted({p['category_id'] for r in records for p in r['detections']})
    add_comic_legend(fig, ids, height, width)
    stem = 'detections_labeled_4x4'
    fig.savefig(output / f'{stem}.png', dpi=dpi, facecolor='white')
    fig.savefig(output / f'{stem}.pdf', dpi=dpi, facecolor='white',
                metadata={'Title': 'SG-DEIM-S DIOR 800: class-labeled predictions'})
    plt.close(fig)
    with Image.open(output / f'{stem}.png') as full:
        full.crop((0, full.height - legend_height, full.width, full.height)).save(
            output / 'class_legend_english_comic.png')
        preview = full.convert('RGB')
        preview.thumbnail((1600, 1800))
        preview.save(output / f'{stem}_preview.jpg', quality=94)


def main(args):
    source, output = Path(args.source).resolve(), Path(args.output).resolve()
    assert source != output
    records = json.loads((source / 'predictions.json').read_text())
    manifest = json.loads((source / 'manifest.json').read_text())
    assert len(records) == 16
    assert ImageFont.truetype(FONT_PATH, FONT_SIZE).getname() == ('Comic Sans MS', 'Bold')
    plt.rcParams['pdf.fonttype'] = 42
    output.mkdir(parents=True, exist_ok=True)
    (output / 'detections').mkdir(exist_ok=True)
    (output / 'originals').mkdir(exist_ok=True)
    layouts = []
    for index, record in enumerate(records):
        original = source / record['original_copy']
        assert sha256(original) == record['source_sha256']
        shutil.copy2(original, output / record['original_copy'])
        image = Image.open(original).convert('RGB')
        assert image.size == (800, 800)
        labels = label_layout(record['detections'])
        assert len(labels) == len(record['detections'])
        layouts.append(labels)
        name = f'{index+1:02d}_{Path(record["file_name"]).stem}_labeled.png'
        draw_individual(image, record['detections'], labels).save(output / 'detections' / name)
        print(f'{index+1:02d}/16 {record["file_name"]}: {len(labels)} class labels', flush=True)
    shutil.copy2(source / 'predictions.json', output / 'predictions.json')
    bilingual_comic_legend(output, records)
    manifest.update(derived_from=str(source),
                    labeled_render_created_utc=datetime.now(timezone.utc).isoformat(),
                    prediction_source_sha256=sha256(source / 'predictions.json'),
                    class_labels=dict(language='English', font='Comic Sans MS', font_style='Bold',
                                      font_file=FONT_PATH, font_sha256=sha256(FONT_PATH),
                                      font_size_pixels=FONT_SIZE,
                                      foreground='white', background='#151515',
                                      count=sum(map(len, layouts))),
                    legend=dict(font='Comic Sans MS', font_style='Bold',
                                font_size_points=LEGEND_FONT_PT, columns=5, rows=4,
                                single_line=True, row_height_pixels=LEGEND_ROW_HEIGHT,
                                height_pixels=LEGEND_HEIGHT))
    write_json(output / 'manifest.json', manifest)
    write_json(output / 'label_layout.json', [dict(file_name=r['file_name'], labels=ls)
                                            for r, ls in zip(records, layouts)])
    render_montage(records, layouts, output)
    lines = [
        '# SG-DEIM-S DIOR 800：Comic Sans MS 单行紧凑图例版', '',
        f'- 使用上一版同一批 16 张图片和完全相同的 {sum(len(r["detections"]) for r in records)} 个预测框，阈值为 {manifest["score_threshold"]}。',
        '- 在每个框旁添加英文类别名；白字深底，标签边缘沿用该类颜色。',
        f'- 框旁类别名使用 Comic Sans MS Bold，{FONT_SIZE} px。',
        f'- 底部图例使用 Comic Sans MS Bold，{LEGEND_FONT_PT} pt，5 列 × 4 行，每个完整类别名保持单行显示。',
        '- 密集区域的标签自动避让，必要时以同色细线连接至对应检测框。',
        '- 图片顺序、预测框坐标、类别、置信度以及类别颜色与上一版一致。',
        '- `detections/`：16 张带类别标签的 800×800 检测图。',
        '- `detections_labeled_4x4.png` / `.pdf`：4×4 总图；PDF 框与类别文字均为矢量。',
        '- `class_legend_bilingual.png`：20 类的中英文对应关系与颜色。',
        '- `class_legend_english_comic.png`：Comic Sans MS 粗体的总图底部图例。',
        '- 英文使用已核验的 Comic Sans MS Bold 字体文件；中文对应说明使用 Noto Sans CJK Bold。',
        '- `originals/`：同一批原始 JPG。',
        '- `predictions.json`：上一版预测文件的逐字节副本。',
        '- `label_layout.json`：每个类别标签的位置及对应预测框索引。', '',
        '| 面板 | 文件名 | 场景 | 标签数 |', '| --- | --- | --- | ---: |',
    ]
    for record in records:
        lines.append(f'| {record["panel"]} | {record["file_name"]} | {record["scene"]} | {len(record["detections"])} |')
    lines += ['', '复现命令：', '', '```bash',
              '/home/user1/anaconda3/envs/deimv2/bin/python tools/inference/label_dior_visualizations.py',
              '```', '']
    (output / 'README.md').write_text('\n'.join(lines))
    bundle_path = output.parent / f'{output.name}.zip'
    with zipfile.ZipFile(bundle_path, 'w', zipfile.ZIP_DEFLATED) as bundle:
        for path in sorted(output.rglob('*')):
            if path.is_file():
                bundle.write(path, arcname=str(path.relative_to(output)))
    print('Saved:', output, flush=True)
    print('Archive:', bundle_path, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', default='outputs/visualizations/SG-DEIM-S_DIOR_800_16')
    parser.add_argument('-o', '--output', default='outputs/visualizations/SG-DEIM-S_DIOR_800_16_comic_singleline')
    main(parser.parse_args())
