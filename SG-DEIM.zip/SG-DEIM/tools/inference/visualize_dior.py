"""Export genuine DIOR predictions, original images and publication figures.

The fixed selection is made from the test split using category/scene coverage.
Ground-truth annotations are used for the image manifest, never for drawing.
"""

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import time
import zipfile

os.environ.setdefault('MPLCONFIGDIR', '/tmp/sg-deim-matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from PIL import Image, ImageDraw, ImageFont
import torch
from torchvision import transforms

REPO_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO_ROOT))
from engine.core import YAMLConfig


# DIOR category IDs are the contiguous 0..19 IDs in the project's COCO JSON.
# Preserve the reference figure's red airplane, pink vehicle, blue ship,
# yellow-green bridge and magenta windmill convention.
CLASS_STYLE = [
    ('airplane', '飞机', '#FF3B30'),
    ('airport', '机场', '#B48CFF'),
    ('baseballfield', '棒球场', '#F59E0B'),
    ('basketballcourt', '篮球场', '#22C55E'),
    ('bridge', '桥梁', '#D7E600'),
    ('chimney', '烟囱', '#00E5FF'),
    ('dam', '水坝', '#FF8C42'),
    ('Expressway-Service-area', '高速公路服务区', '#A8F070'),
    ('Expressway-toll-station', '高速公路收费站', '#00B8A9'),
    ('golffield', '高尔夫球场', '#9D4EDD'),
    ('groundtrackfield', '田径场', '#FFD166'),
    ('harbor', '港口', '#47B5FF'),
    ('overpass', '立交桥', '#EAE2B7'),
    ('ship', '船舶', '#6C63FF'),
    ('stadium', '体育场', '#D3549A'),
    ('storagetank', '储罐', '#FFB4A2'),
    ('tenniscourt', '网球场', '#00A86B'),
    ('trainstation', '火车站', '#9BB1CE'),
    ('vehicle', '车辆', '#FF87B5'),
    ('windmill', '风机', '#F538D2'),
]


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def clipped_box(box, width, height):
    x1, y1, x2, y2 = box
    return [max(0, min(width - 1, x1)), max(0, min(height - 1, y1)),
            max(0, min(width - 1, x2)), max(0, min(height - 1, y2))]


def draw_predictions(image, predictions):
    result = image.copy()
    painter = ImageDraw.Draw(result)
    # Large boxes first, so small-object borders remain visible.
    ordered = sorted(predictions, key=lambda p: (
        p['box_xyxy'][2] - p['box_xyxy'][0]
    ) * (p['box_xyxy'][3] - p['box_xyxy'][1]), reverse=True)
    for pred in ordered:
        box = clipped_box(pred['box_xyxy'], *image.size)
        if box[2] > box[0] and box[3] > box[1]:
            painter.rectangle(box, outline=CLASS_STYLE[pred['category_id']][2], width=2)
    return result


def add_legend(fig, class_ids, bottom, total_height, total_width):
    columns = 5
    cell_width = (total_width - 40) / columns
    for index, category_id in enumerate(class_ids):
        row, col = divmod(index, columns)
        x = (24 + col * cell_width) / total_width
        y = (bottom - 44 - row * 52) / total_height
        color = CLASS_STYLE[category_id][2]
        fig.add_artist(Rectangle((x, y), 44 / total_width, 20 / total_height,
                                 transform=fig.transFigure, fill=False,
                                 edgecolor=color, linewidth=1.2))
        fig.text(x + 58 / total_width, y + 10 / total_height,
                 CLASS_STYLE[category_id][0], fontfamily='DejaVu Serif',
                 fontsize=10.2, va='center', color='#111111')


def montage(records, output, predictions=True):
    # Each source image has 800 pixels; keep its native detail in the PNG.
    tile, gap, margin = 800, 8, 12
    grid_size = tile * 4 + gap * 3
    legend_ids = sorted({p['category_id'] for r in records for p in r['detections']})
    legend_rows = (len(legend_ids) + 4) // 5
    legend_height = 38 + legend_rows * 52 if predictions else 0
    width = grid_size + margin * 2
    height = grid_size + margin * 2 + legend_height
    dpi = 200
    fig = plt.figure(figsize=(width / dpi, height / dpi), dpi=dpi, facecolor='white')
    for index, record in enumerate(records):
        row, col = divmod(index, 4)
        left = margin + col * (tile + gap)
        top = margin + row * (tile + gap)
        ax = fig.add_axes([left / width, (height - top - tile) / height,
                           tile / width, tile / height])
        image = Image.open(output / record['original_copy']).convert('RGB')
        ax.imshow(image, interpolation='none')
        ax.set_xlim(-.5, 799.5)
        ax.set_ylim(799.5, -.5)
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_linewidth(.35)
            spine.set_edgecolor('#888888')
        if predictions:
            ordered = sorted(record['detections'], key=lambda p: (
                p['box_xyxy'][2] - p['box_xyxy'][0]
            ) * (p['box_xyxy'][3] - p['box_xyxy'][1]), reverse=True)
            for pred in ordered:
                x1, y1, x2, y2 = clipped_box(pred['box_xyxy'], 800, 800)
                if x2 > x1 and y2 > y1:
                    ax.add_patch(Rectangle((x1, y1), x2 - x1, y2 - y1,
                                           fill=False, linewidth=.72,
                                           edgecolor=CLASS_STYLE[pred['category_id']][2]))
        ax.text(.018, .978, record['panel'], transform=ax.transAxes,
                va='top', ha='left', fontsize=10.5, color='white',
                bbox=dict(facecolor='black', alpha=.65, edgecolor='none', pad=2.2))
    if predictions:
        add_legend(fig, legend_ids, legend_height - 8, height, width)
    stem = 'detections_4x4' if predictions else 'originals_4x4'
    fig.savefig(output / f'{stem}.png', dpi=dpi, facecolor='white')
    fig.savefig(output / f'{stem}.pdf', dpi=dpi, facecolor='white',
                metadata={'Title': f'SG-DEIM-S DIOR 800: {stem}',
                          'Creator': 'SG-DEIM genuine checkpoint inference'})
    plt.close(fig)
    with Image.open(output / f'{stem}.png') as image:
        preview = image.convert('RGB')
        preview.thumbnail((1600, 1800))
        preview.save(output / f'{stem}_preview.jpg', quality=94)


def bilingual_legend(output, class_counts):
    font_path = '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
    font = ImageFont.truetype(font_path, 25)
    small = ImageFont.truetype(font_path, 21)
    canvas = Image.new('RGB', (1800, 900), 'white')
    painter = ImageDraw.Draw(canvas)
    painter.text((30, 20), 'DIOR 类别颜色图例 / Class color legend', fill='black', font=font)
    for index, (english, chinese, color) in enumerate(CLASS_STYLE):
        col, row = divmod(index, 10)
        x, y = 35 + col * 890, 85 + row * 78
        painter.rectangle((x, y + 9, x + 62, y + 37), outline=color, width=4)
        painter.text((x + 82, y), f'{chinese} / {english}', fill='#111111', font=small)
        painter.text((x + 82, y + 30),
                     f'ID {index:02d}    {color}    检测框数量: {class_counts[index]}',
                     fill='#555555', font=small)
    canvas.save(output / 'class_legend_bilingual.png')


def write_readme(output, records, manifest, class_counts):
    lines = [
        '# SG-DEIM-S / DIOR / 800×800：16 张代表场景可视化', '',
        f'- 配置：`{manifest["config"]}`',
        f'- 检测器权重：`{manifest["checkpoint"]}`；使用 EMA 参数，严格加载全部参数。',
        '- 权重选择：800×800、batch 8 训练目录中的 `best_stg2.pth`。',
        f'- 同目录训练日志全程最佳验证集 AP：{100 * manifest["training_log_best_val_ap"]:.4f}%；此数字不是这 16 张图片的性能指标。',
        f'- 推理输入：800×800；设备：{manifest["device"]}；FP32。',
        f'- 统一置信度阈值：{manifest["score_threshold"]}；保留模型原有 top-300 后处理，不额外执行 NMS。',
        '- 按场景多样性、类别覆盖、目标密度、尺度差异和预测可读性人工选取独立 test 集图片，供定性展示，不代表全测试集性能。',
        '- 所有彩色框均来自模型预测；未用标注框替代预测、补框、修框或按类别额外过滤。',
        '- 面板顺序为从左到右、从上到下；同一类别在所有图片中颜色一致。',
        '- `originals/` 是逐字节复制的原始 JPG，未绘框、裁剪、缩放或重新编码。', '',
        '## 文件', '',
        '- `detections_4x4.png` / `.pdf`：4×4 检测总图，底部为实际检出类别图例；PDF 框为矢量。',
        '- `originals_4x4.png` / `.pdf`：同顺序原图总图；面板字母仅用于与检测总图对应。',
        '- `*_preview.jpg`：便于快速查看的缩略预览；完整细节请使用 PNG / PDF。',
        '- `detections/`：16 张 800×800 单图检测结果，无文字遮挡目标。',
        '- `class_legend_bilingual.png`：全部 20 类的中英文、颜色和本次检测框数量。',
        '- `predictions.json`：保留框与全部 top-300 原始预测；框坐标为原图像素 xyxy。',
        '- `manifest.json`：权重哈希、归一化、输入大小、阈值、原图哈希与来源信息。', '',
        '## 图片对应关系', '',
        '| 面板 | DIOR 原文件 | 场景 | 检出框数 | 检出类别（中英文图例见下） |',
        '| --- | --- | --- | ---: | --- |',
    ]
    for record in records:
        counts = Counter(p['category_id'] for p in record['detections'])
        classes = '；'.join(f'{CLASS_STYLE[c][1]}×{counts[c]}' for c in sorted(counts))
        lines.append(f'| {record["panel"]} | {record["file_name"]} | {record["scene"]} | '
                     f'{len(record["detections"])} | {classes} |')
    lines += ['', '## 颜色与类别', '', '| ID | 英文 | 中文 | 颜色 HEX | 框数 |',
              '| ---: | --- | --- | --- | ---: |']
    for cid, (english, chinese, color) in enumerate(CLASS_STYLE):
        lines.append(f'| {cid} | {english} | {chinese} | `{color}` | {class_counts[cid]} |')
    lines += ['', '## 复现命令', '', '在项目根目录执行：', '', '```bash',
              '/home/user1/anaconda3/envs/deimv2/bin/python tools/inference/visualize_dior.py',
              '```', '']
    (output / 'README.md').write_text('\n'.join(lines))


def archive(output):
    originals_zip = output.parent / f'{output.name}_originals.zip'
    with zipfile.ZipFile(originals_zip, 'w', zipfile.ZIP_DEFLATED) as bundle:
        for path in sorted((output / 'originals').iterdir()):
            bundle.write(path, arcname=path.name)
    full_zip = output.parent / f'{output.name}_complete.zip'
    with zipfile.ZipFile(full_zip, 'w', zipfile.ZIP_DEFLATED) as bundle:
        for path in sorted(output.rglob('*')):
            if path.is_file():
                bundle.write(path, arcname=str(path.relative_to(output)))
    return originals_zip, full_zip


def main(args):
    torch.set_num_threads(args.threads)
    device = 'cuda' if args.device == 'auto' and torch.cuda.is_available() else args.device
    if device == 'auto':
        device = 'cpu'
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    for folder in ('originals', 'detections'):
        (output / folder).mkdir(exist_ok=True)
    selection = json.loads(Path(args.selection).read_text())
    assert len(selection) == 16 and len({r['file_name'] for r in selection}) == 16
    dataset = json.loads(Path(args.annotations).read_text())
    image_index = {image['file_name']: image for image in dataset['images']}
    gt = defaultdict(Counter)
    for annotation in dataset['annotations']:
        gt[annotation['image_id']][annotation['category_id']] += 1
    for category in dataset['categories']:
        assert CLASS_STYLE[category['id']][0] == category['name']
    assert len({style[2] for style in CLASS_STYLE}) == 20

    cfg = YAMLConfig(args.config)
    assert cfg.yaml_cfg['eval_spatial_size'] == [800, 800]
    # The complete detector checkpoint contains the backbone as well.
    cfg.yaml_cfg['DINOv3STAs']['weights_path'] = None
    checkpoint = torch.load(args.resume, map_location='cpu', weights_only=False)
    state = checkpoint['ema']['module']
    model = cfg.model.eval()
    load_result = model.load_state_dict(state, strict=True)
    model = model.to(device)
    postprocessor = cfg.postprocessor.eval().to(device)
    print('Checkpoint:', args.resume, load_result, flush=True)
    normalize = next(op for op in cfg.yaml_cfg['val_dataloader']['dataset']['transforms']['ops']
                     if op['type'] == 'Normalize')
    preprocess = transforms.Compose([
        transforms.Resize((800, 800)), transforms.ToTensor(),
        transforms.Normalize(normalize['mean'], normalize['std']),
    ])
    records = []
    class_counts = Counter()
    for index, selected in enumerate(selection):
        meta = image_index[selected['file_name']]
        source = Path(args.images) / meta['file_name']
        image = Image.open(source).convert('RGB')
        assert image.size == (800, 800)
        original_copy = Path('originals') / f'{index + 1:02d}_{meta["file_name"]}'
        shutil.copy2(source, output / original_copy)
        tensor = preprocess(image).unsqueeze(0).to(device)
        sizes = torch.tensor([image.size], device=device)
        start = time.perf_counter()
        with torch.inference_mode():
            prediction = postprocessor(model(tensor), sizes)[0]
        if device.startswith('cuda'):
            torch.cuda.synchronize()
        elapsed = time.perf_counter() - start
        raw = []
        for label, box, score in zip(prediction['labels'].cpu().tolist(),
                                      prediction['boxes'].cpu().tolist(),
                                      prediction['scores'].cpu().tolist()):
            assert 0 <= label < 20
            assert all(torch.isfinite(torch.tensor(box)))
            raw.append(dict(category_id=label, category=CLASS_STYLE[label][0],
                            score=score, box_xyxy=box))
        retained = [pred for pred in raw if pred['score'] >= args.score_threshold]
        class_counts.update(p['category_id'] for p in retained)
        record = dict(selected, panel=f'({chr(97 + index)})', image_id=meta['id'],
                      source=str(source), original_copy=str(original_copy),
                      source_sha256=sha256(source), gt_class_counts=dict(gt[meta['id']]),
                      inference_seconds=elapsed, detections=retained, raw_top300=raw)
        records.append(record)
        draw_predictions(image, retained).save(output / 'detections' / f'{index+1:02d}_{source.stem}.png')
        print(f'{index+1:02d}/16 {source.name}: {len(retained)} detections, {elapsed:.2f}s', flush=True)

    log_rows = [json.loads(line) for line in (Path(args.resume).parent / 'log.txt').read_text().splitlines()
                if line.strip()]
    best_logged_ap = max(row['test_coco_eval_bbox'][0] for row in log_rows)
    manifest = dict(created_utc=datetime.now(timezone.utc).isoformat(),
                    config=args.config, checkpoint=args.resume,
                    checkpoint_sha256=sha256(args.resume),
                    checkpoint_saved_last_epoch=checkpoint.get('last_epoch'),
                    checkpoint_parameters='ema.module', strict_load=True,
                    training_log_best_val_ap=best_logged_ap,
                    input_size=[800,800], device=device, precision='float32',
                    normalization=normalize, score_threshold=args.score_threshold,
                    postprocessing='original top-300, no additional NMS',
                    dataset_split='test', annotations=args.annotations,
                    selection_file=args.selection, selected_image_count=len(records),
                    drawn_box_count=sum(class_counts.values()),
                    selection_uses='scene diversity, annotation category coverage, visual inspection and prediction readability; qualitative selection',
                    colors=[dict(id=i,english=s[0],chinese=s[1],hex=s[2],
                                 predicted_count=class_counts[i]) for i,s in enumerate(CLASS_STYLE)],
                    sources=[{key: r[key] for key in ('panel','file_name','source','original_copy','source_sha256')}
                             for r in records])
    write_json(output / 'predictions.json', records)
    write_json(output / 'manifest.json', manifest)
    montage(records, output, predictions=True)
    montage(records, output, predictions=False)
    bilingual_legend(output, class_counts)
    write_readme(output, records, manifest, class_counts)
    originals_zip, full_zip = archive(output)
    print('Done:', output, flush=True)
    print('Detected classes:', len(class_counts), 'boxes:', sum(class_counts.values()), flush=True)
    print('Originals archive:', originals_zip, flush=True)
    print('Complete archive:', full_zip, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('-c', '--config', default='configs/sgdeim/sgdeim_dinov3_s_dior_hbb.yml')
    parser.add_argument('-r', '--resume', default='outputs/SG-DEIM_dinov3_s_dior_hbb_800_bs8/best_stg2.pth')
    parser.add_argument('--selection', default='configs/visualization/dior_s_800_16.json')
    parser.add_argument('--annotations', default='data/dior/annotations/test.json')
    parser.add_argument('--images', default='/media/q/data2/ys/data/OpenDataLab___DIOR/raw/DIOR/JPEGImages-test')
    parser.add_argument('-o', '--output', default='outputs/visualizations/SG-DEIM-S_DIOR_800_16')
    parser.add_argument('--device', default='auto')
    parser.add_argument('--threads', type=int, default=4)
    parser.add_argument('--score-threshold', type=float, default=.4)
    main(parser.parse_args())
